<?php
    require 'connection.php';
    $id = $_GET['id'];
    $query = "DELETE FROM `ads` WHERE id = '$id'";

    if (mysqli_query($connection, $query)) {
        header('location: index.php?msg=Ad has been deleted');
    } else {
        header("location: index.php?msg=Error while deleting");
    }