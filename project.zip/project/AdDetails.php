<?php
session_start();
require 'connection.php';

@$id = $_GET['id'];

$query = "SELECT * FROM `ads` where id = '$id'";
$data = mysqli_query($connection, $query);
$data = mysqli_fetch_assoc($data);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Ad Details</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/AdDetails.css" />
	<link rel="stylesheet" type="text/css" href="css/deal.css" />


	<style>
		.shop_bt:hover {
			text-decoration: underline;
			background-color: rgb(27, 39, 51);
		}

		a:hover {
			text-decoration: underline;

		}
	</style>

</head>

<body>
	<div class="limiter">
		<!--Header-->

		<div class="header" style="background-color:darkcyan;">
			<div class="log" style="margin-top:30px; margin-left:50px; width:50px;"><a href="index.php" style="background:white;color:black;">Home</a></div>
			<div class="logo">
				<img src="images/logo.png" height="150px" style="margin-top: -20px;margin-left:-150px;" />
			</div>
			<div style="clear: both"></div>
		</div>
		<div style="clear:both;"></div>
	</div>


	<!--ENd Header-->
	<div class="container-login100" style="background: #f0f0f2;">
		<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54" style="padding-left: 100px; padding-right:100px; padding-top: 50px; padding-bottom: 50px;">


			<div class="slideshow-container">

				<div class="mySlides fade">
					<div class="numbertext">1 / 3</div>
					<img src="<?= $data['image_1']; ?>" style="width:100%; border-radius: 5px;">
				</div>

				<div class="mySlides fade">
					<div class="numbertext">2 / 3</div>
					<img src="<?= $data['image_2']; ?>" style="width:100%; border-radius: 5px;">
				</div>

				<div class="mySlides fade">
					<div class="numbertext">3 / 3</div>
					<img src="<?= $data['image_3']; ?>" style="width:100%; border-radius: 5px;">
				</div>

				<a class="prev" onclick="plusSlides(-1)">❮</a>
				<a class="next" onclick="plusSlides(1)">❯</a>

			</div>
			<span class="login100-form-title" style="text-align:left ; font-size:25px;">
				<?= $data['title']; ?>
			</span>
			<br>
			<span class="login100-form-title" style="text-align:left ; font-size:25px;">
				Details
			</span>
			<br>

			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">Category</span>
				<span class="label-input100" style="display: inline; margin-left: 400px;"><?= $data['category']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">Make</span>
				<span class="label-input100" style="display: inline; margin-left: 430px;"><?= $data['company']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">Model</span>
				<span class="label-input100" style="display: inline; margin-left: 425px;"><?= $data['model']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">Year</span>
				<span class="label-input100" style="display: inline; margin-left: 435px;"><?= $data['year']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">Fuel Type</span>
				<span class="label-input100" style="display: inline; margin-left: 400px;"><?= $data['fuel_type']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">KM Driven</span>
				<span class="label-input100" style="display: inline; margin-left: 398px;"><?= $data['km_driven']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">Phone No</span>
				<span class="label-input100" style="display: inline; margin-left: 400px;"><?= $data['mobile']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">Added By</span>
				<span class="label-input100" style="display: inline; margin-left: 400px;"><?= $data['name']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline-block;">seller City</span>
				<span class="label-input100" style="display: inline; margin-left: 400px;"><?= $data['city']; ?></span>
			</div>
			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired">
				<span class="label-input100" style="display: inline;">Location</span>
				<span class="label-input100" style="display: inline; margin-left: 400px;"><?= $data['location']; ?></span>
			</div>

			<br>
			<div class="wrap-input100 validate-input m-b-23" data-validate="Username is reauired" style="border-bottom: 0px;">
				<span class="label-input100" style="display: inline;"></span>
			</div>
			<div class="wrap-input100 validate-input m-b-23">
				<span class="label-input100"><b>Description:</b></span>
				<input class="shop_dis" name="" type="text" readonly value="<?= $data['ad_description']; ?>" />
			</div>
			<br>
			<div>
			</div>
		</div>
	</div>
		 <!-- Start footer -->
		 <div class="footer" style="height: 250px;background:darkcyan; border-top: 5px solid black;">
      <div class="f1">
        
        <p>
          <b>Widely</b> known as Pakistan's no. 1 online classifieds platform,
          where you can sale rent and purchase your cars without any worry
          Our aim is to empower every person in the country to
          independently connect with buyers and sellers online. We care about
          you — and the transactions that bring you closer to your dreams.
          Want to buy your first car? We’re here for you. Want to sell
          commercial property to buy your dream home? We’re here for you.
          Whatever job you’ve got, we promise to get it done.
        </p>

        
      </div>

      <div class="f3">
        <h2>SOCIAL</h2>
        <ul>
          <a href="https://www.facebook.com/aqsa.shafiq.1111">
            <li><img src="images/fb.png" /></li>
          </a>
          <a href="https://twitter.com/ManiJut07962763">
            <li><img src="images/twitter.png" /></li>
          </a>
         
          <a href="https://youtube.com/channel/UCjccFNGaezJHBEkL8XLTdug">
            <li><img src="images/you.png" /></li>
          </a>
        </ul>

        <div class="post_ad" style="  background:white; color: black;">POST AD</div>
      </div>

      <div class="f2">
        <h2 style="padding-left: 50px; color: #f1f1f1">
          <i class="fa fa-building" aria-hidden="true"></i> CITIES
        </h2>
        <ul class="f_2">
          <li>Karachi</li>
          <li>Faisalabad</li>
          <li>Multan</li>
          <li>Gujranwala</li>

        </ul>

        <ul class="f_2">
          <li>Lahore</li>
          <li>Rawalpindi</li>
          <li>Peshawar</li>
          <li>Quetta</li>

        </ul>

        <ul class="f_2">
          <li>Islamabad</li>
          <li>Bahawalpur</li>
          <li>Okara</li>
          <li>Jhelum</li>
 
          
        </ul>
      </div>

      <div style="clear: both"></div>
    </div>
    <!--End Footer-->
	</div>


	<script>
		let slideIndex = 1;
		showSlides(slideIndex);

		function plusSlides(n) {
			showSlides(slideIndex += n);
		}

		function currentSlide(n) {
			showSlides(slideIndex = n);
		}

		function showSlides(n) {
			let i;
			let slides = document.getElementsByClassName("mySlides");
			let dots = document.getElementsByClassName("dot");
			if (n > slides.length) {
				slideIndex = 1
			}
			if (n < 1) {
				slideIndex = slides.length
			}
			for (i = 0; i < slides.length; i++) {
				slides[i].style.display = "none";
			}
			for (i = 0; i < dots.length; i++) {
				dots[i].className = dots[i].className.replace(" active", "");
			}
			slides[slideIndex - 1].style.display = "block";
			dots[slideIndex - 1].className += " active";
		}
	</script>
</body>

</html>
