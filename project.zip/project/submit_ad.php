<?php
	include "connection.php";
	session_start();
	$user_id = $_SESSION['id'];
	
	if (isset($_POST)) {
		/*
			Get Images
		*/
		// Image 1
		$img1 = $_FILES['image1']['name'];
		$temp1 = explode(".", $img1);
		$newfilename1 = round(microtime(true)) . '1.' . end($temp1);
		$imagepath1="ads_images/".$newfilename1;
		move_uploaded_file($_FILES["image1"]["tmp_name"],$imagepath1);

		// Image 2
		$img2 = $_FILES['image2']['name'];
		$temp2 = explode(".", $img2);
		 $newfilename2 = round(microtime(true)) . '2.' . end($temp2);
		$imagepath2="ads_images/".$newfilename2;
		move_uploaded_file($_FILES["image2"]["tmp_name"],$imagepath2);

		// Image 3
		$img3 = $_FILES['image3']['name'];
		$temp3 = explode(".", $img3);
		 $newfilename3 = round(microtime(true)) . '3.' . end($temp3);
		$imagepath3="ads_images/".$newfilename3;
		move_uploaded_file($_FILES["image3"]["tmp_name"],$imagepath3);

		// Image 4
		$img4 = $_FILES['image4']['name'];
		$temp4 = explode(".", $img4);
		 $newfilename4 = round(microtime(true)) . '4.' . end($temp4);
		$imagepath4="ads_images/".$newfilename4;
		move_uploaded_file($_FILES["image4"]["tmp_name"],$imagepath4);

		// Get the data
		$title = $_POST['title'];
		$category = $_POST['category'];
		$price = $_POST['price'];
		$company = $_POST['company'];
		$year = $_POST['year'];
		$model = $_POST['model'];
		$fuelType = $_POST['fuelType'];
		$kmDriven = $_POST['kmDriven'];
		$description = $_POST['description'];
		$location = $_POST['location'];
		$name = $_POST['name'];
		$phone = $_POST['phone'];
		$city = $_POST['city'];

		// Insert into Database
		$query = "insert into ads(title, category, price, company, year, model, fuel_type, km_driven, ad_description, location, image_1, image_2, image_3, image_4, name, mobile, city, user_id)
		 values ('$title','$category','$price','$company','$year','$model','$fuelType','$kmDriven','$description','$location','$imagepath1','$imagepath2','$imagepath3','$imagepath4','$name', '$phone','$city', '$user_id')";

		 if (mysqli_query($connection, $query)) {
			echo("<script>location.href = 'index.php?msg=Ad has been posted successfully';</script>");
		} else {
			 echo "Erro while submit ad : " . mysqli_error($connection);
		}

	}