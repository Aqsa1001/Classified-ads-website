<?php	
	require 'connection.php';
	session_start();

	$id = $_SESSION['id'];
	$query = "SELECT * FROM `ads` where user_id = '$id'";
	$run = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Account Setting</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" type="text/css" href="css/account.css" />
	<link rel="stylesheet" type="text/css" href="css/deal.css" />

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
	<!--===============================================================================================-->
	<Style>
		a:hover {
			text-decoration: underline;

		}

		hr {
			height: 6px;
			background: url(../images/hr-12.png) repeat-x 0 0;
			border: 0;
		}

		.s_box_right:hover {
			text-decoration: underline;
		}

		.s_box_right-del:hover {
			text-decoration: underline;
		}
	</Style>

</head>

<body>
<body style="background: #f0f0f2;">
	<!--Header-->

	<div class="header" style="background-color:darkcyan;">
		<div class="log" style="margin-top:30px; margin-left:50px; width:50px;"><a href="index.php" style="background:white;color:black;">Home</a></div>
		<div class="logo">
			<img src="images/logo.png" height="150px" style="margin-top: -20px;margin-left:-150px;" />
		</div>
		<div style="clear: both"></div>
	</div>
	<div style="clear:both;"></div>
	</div>


	<!--ENd Header-->
			<div class="container-login100">
				<div class="wrap-login100 "
					style="padding-left: 100px; padding-right:100px; padding-top: 50px; padding-bottom: 50px;width: 50%;">
						<span class="login100-form-title">
							Your Ads:
						</span>


						<div class="search_display">
							<ul class="my_search">

								<?php while($data = mysqli_fetch_array($run)) { ?>
								<li>
									<div class="s_box">
										<div class="s_pic"><img src="<?= $data['image_1']; ?>" width="100%" /></div>
										<div class="s_name"><a href="#"><?= $data['title']; ?></a></div>
										<div class="s_km"><?= $data['km_driven']; ?> KM</div>
										<div class="s_prise">Rs.<?= $data['price']; ?></div>
									</div>

									<div class="s_box_bottom">
										<div class="s_box_left">Category: <?= substr($data['category'], 0, 15); ?></div>
										<div class="s_box_right-del" style="background-color:darkcyan;">
											<a href="edit_ad.php?id=<?= $data['id'] ?>">EDIT</a></div>
										<div class="s_box_right" style="background-color:darkcyan;">
											<a onclick="return confirm('Are you sure you want to delete this')" href="delete_ad.php?id=<?= $data['id']; ?>">DELETE</a></div>
										<div style="clear:both;"></div>
									</div>
								</li>
								<?php } ?>
								<div style="clear:both;"></div>
							</ul>

						</div>
				</div>
			</div>
			


</body>

</html>
