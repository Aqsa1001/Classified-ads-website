<?php
session_start();
require 'connection.php';
$id = $_SESSION['id'];
$query = "SELECT * FROM `user_info` where id = $id";
$result = mysqli_query($connection, $query);
$data = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Account Setting</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/account.css" />
	<link rel="stylesheet" type="text/css" href="css/deal.css" />
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
	<style>
    .mybtn:hover {
      text-decoration: underline;
     
    }
	a:hover {
      text-decoration: underline;
     
    }
  </style>

</head>

<body style="background: #f0f0f2;">
<div class="main_wrapper">
	 <!--Header-->
	 <div class="header"style="background-color:darkcyan;">
    	<div class="log" style="margin-top:30px; margin-left:50px; width:50px;" ><a href="index.php" style="background:white;color:black;">Home</a></div>
    	<div class="logo">
      	<img src="images/logo.png" height="150px" style="margin-top: -20px;margin-left:-150px;" />
    	</div>
    	<div style="clear: both"></div>
  	</div>
  <div style="clear:both;"></div>
    <!--ENd Header-->
			<div class="container-login100" >
				<div class="wrap-login100 " style="padding-left: 100px; padding-right:100px; padding-top: 50px; padding-bottom: 50px;width: 50%;">
					<span class="login100-form-title">
						Your Info:
					</span>

					<div class="wrap-input100 validate-input " >
						<span class="label-input100">Full Name</span>
						<input class="input100" type="text" readonly name="username" placeholder="Type your username" value="<?= $data['name'] ?>">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<span class="label-input100">Phone Number</span>
						<input class="input100" readonly type="text" name="phoneNo" placeholder="XXXX-XXXXXXX" value="<?= $data['phoneNo']; ?>" />
						<span class="focus-input100" data-symbol="&#9743;"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<span class="label-input100">City</span>
						<input class="input100" type="text" readonly name="city" placeholder="Type  your City name" value="<?= $data['city']; ?>" />
						<span class="focus-input100" data-symbol="&#xf286;"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<span class="label-input100">Email</span>
						<input class="input100" type="text" readonly name="email" placeholder="Type  your email" value="<?= $data['email']; ?>" />
						<span class="focus-input100" data-symbol="&#9993;"></span>
					</div>
					<br>
					<span id="error"></span>
					<br>

					<br>
					<div class="w3-show-inline-block">
  						<div class="w3-bar">
    						<button class="w3-btn w3-teal mybtn"onclick="window.location='edit_account.php';" style="margin-left:100px;width:100px;border-radius:5px;font-family: Poppins-Regular;font-size: 16px;">Edit</button>
    						<button class="w3-btn w3-teal mybtn" onclick="window.location='index.php';"style="margin-left:60px ;width:100px;border-radius:5px;font-family: Poppins-Regular;font-size: 16px;">Cancel</button>
  						</div>
  					</div>					
					
				</div>
			</div>
</div>
</body>

</html>

