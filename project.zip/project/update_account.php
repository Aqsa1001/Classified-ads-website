<?php
session_start();
$id = $_SESSION['id'];
require 'connection.php';

if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $phone = $_POST['phone'];
    $city = $_POST['city'];

    $update_query = "UPDATE user_info SET name = '$name', email = '$email', password = '$password', phoneNo = '$phone', city = '$city' WHERE id = '$id'";
    if (mysqli_query($connection, $update_query)) {
        echo("<script>location.href = 'index.php?msg=Account settings have been updated';</script>");
    } else {
        echo "Erro while login : " . mysqli_error($connection);
    }

}
?>