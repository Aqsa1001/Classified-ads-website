﻿<?php
    session_start();
    require 'connection.php';
    $search = $_GET['search'];
    $query = mysqli_query($connection, "SELECT * FROM `ads` where title LIKE '%$search%'") or die ("Could not search");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Search</title>
<link rel="stylesheet" type="text/css" href="css/deal.css" />
<link rel="stylesheet" type="text/css" href="css/second_page.css" />
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/left_menu_panel.css" />
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

<link rel="stylesheet" href="css/left_menu_css.css">
   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="js/script.js"></script>
   
  <link rel="stylesheet" type="text/css" href="jquery.bxslider.css">
  <link rel="stylesheet" type="text/css" href="jquery.bxslider.min.css">

  <style>
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<!--Header-->

  <div class="header" style="background-color:darkcyan;">
    <div class="log" style="margin-top:30px; margin-left:50px; width:50px;"><a href="index.php"
        style="background:white;color:black;">Home</a></div>
    <div class="logo">
      <img src="images/logo.png" height="150px" style="margin-top: -20px;margin-left:-150px;" />
    </div>
    <div style="clear: both"></div>
  </div>
  <div style="clear:both;"></div>
  </div>


  <!--ENd Header-->

  
          <div class="search_display">
             <ul class="my_search">
                <?php while($data = mysqli_fetch_array($query)) { ?>
               <li>
                 <div class="s_box">
                     <div class="s_pic"><img src="<?= $data['image_1'] ?>" width="100%" /></div>
                     <div class="s_name"><a href="AdDetails.php?id=<?= $data['id']; ?>"><?= $data['title'] ?></a></div>
                     <div class="s_km"><?= $data['km_driven'] ?> KM</div>
                     <div class="s_prise">Rs. <?= $data['price'] ?></div>
                  </div>
                  
                  <div class="s_box_bottom">
                  <div class="s_box_left">Category : <?= $data['category']; ?></div>
                     <div class="s_box_right" style="background:darkcyan; "><a href="AdDetails.php?id=<?= $data['id']; ?>">View</a></div>
                     <div style="clear:both;"></div>
                  </div>
               </li>
               <?php } ?>
               <div style="clear:both;"></div>
             </ul>
          </div>
   <!--ENd Content-->
   
    <!-- Start footer -->
    <div class="footer" style="height: 150px;background:darkcyan; border-top: 5px solid black;">
      <div class="f1">
        
        <p>
          <b>Widely</b> known as Pakistan's no. 1 online classifieds platform,
          where you can sale rent and purchase your cars without any worry
          Our aim is to empower every person in the country to
          independently connect with buyers and sellers online. We care about
          you — and the transactions that bring you closer to your dreams.
          Want to buy your first car? We’re here for you. Want to sell
          commercial property to buy your dream home? We’re here for you.
          Whatever job you’ve got, we promise to get it done.
        </p>

        
      </div>

      <div class="f3">
        <h2>SOCIAL</h2>
        <ul>
          <a href="https://www.facebook.com/aqsa.shafiq.1111">
            <li><img src="images/fb.png" /></li>
          </a>
          <a href="https://twitter.com/ManiJut07962763">
            <li><img src="images/twitter.png" /></li>
          </a>
         
          <a href="https://youtube.com/channel/UCjccFNGaezJHBEkL8XLTdug">
            <li><img src="images/you.png" /></li>
          </a>
        </ul>

        <div class="post_ad" style="  background:white; color: black;">POST AD</div>
      </div>

      <div class="f2">
        <h2 style="padding-left: 50px; color: #f1f1f1">
          <i class="fa fa-building" aria-hidden="true"></i> CITIES
        </h2>
        <ul class="f_2">
          <li>Karachi</li>
          <li>Faisalabad</li>
          <li>Multan</li>
          <li>Gujranwala</li>

        </ul>

        <ul class="f_2">
          <li>Lahore</li>
          <li>Rawalpindi</li>
          <li>Peshawar</li>
          <li>Quetta</li>

        </ul>

        <ul class="f_2">
          <li>Islamabad</li>
          <li>Bahawalpur</li>
          <li>Okara</li>
          <li>Jhelum</li>
 
          
        </ul>
      </div>

      <div style="clear: both"></div>
    </div>
    <!--End Footer-->
</div>


<script type="text/javascript">
  $(window).scroll(function(){
      if ($(this).scrollTop() > 135) {
          $('.searchbar').addClass('fixed');
      } else {
          $('.searchbar').removeClass('fixed');
      }
  });
</script>



<script src="jquery.bxslider.js" type="text/javascript"></script>
  <script src="jquery.bxslider.min.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).ready(function(){
  $('.slider1').bxSlider({
    slideWidth: 150,
	slideHeight: 180,
    minSlides: 4,
    maxSlides: 8,
    slideMargin: 15
  });
});
</script>



</body>
</html>
