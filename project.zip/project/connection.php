<?php

$connection=new mysqli("localhost","root","","project");
if($connection)
{
	// echo "Connection established";
}
else
{
	echo "Connection not established";
}



