<?php
include "connection.php";
session_start();
    if (isset($_POST) ){
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        $sql = "SELECT * FROM user_info WHERE email='$email' AND password='$password'";
        
        $result=$connection->query($sql);
            if (mysqli_num_rows($result) === 1) {
                $row = mysqli_fetch_assoc($result);
                if ($row['email'] === $email && $row['password'] === $password) {
                    $_SESSION['name'] = $row['name'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['city'] = $row['city'];
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['phone'] = $row['phoneNo'];
                    header("location: index.php?msg=Welcome back ". $_SESSION['name']);
                }
            } else {
                header("location: index.php?err=Error while loggin please try again.");
            }
    }
?>
            