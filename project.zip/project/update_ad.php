<?php
    require 'connection.php';
    session_start();

    if (isset($_POST)) {

		/*
			Get Images
		*/

		// Image 1
        if (!empty($_FILES['image1']['name'])) {
            $img1 = $_FILES['image1']['name'];
            $temp1 = explode(".", $img1);
            $newfilename1 = round(microtime(true)) . '1.' . end($temp1);
            $imagepath1="ads_images/".$newfilename1;
            move_uploaded_file($_FILES["image1"]["tmp_name"],$imagepath1);
        } else {
            $imagepath1 = $_POST['image_1'];
        }
		
		// Image 2
        if (!empty($_FILES['image2']['name'])) {
            $img2 = $_FILES['image2']['name'];
            $temp2 = explode(".", $img2);
             $newfilename2 = round(microtime(true)) . '2.' . end($temp2);
            $imagepath2="ads_images/".$newfilename2;
            move_uploaded_file($_FILES["image2"]["tmp_name"],$imagepath2);
        } else {
            $imagepath2 = $_POST['image_2'];
        }
		
		// Image 3
        if (!empty($_FILES['image3']['name'])) {
            $img3 = $_FILES['image3']['name'];
            $temp3 = explode(".", $img3);
             $newfilename3 = round(microtime(true)) . '3.' . end($temp3);
            $imagepath3="ads_images/".$newfilename3;
            move_uploaded_file($_FILES["image3"]["tmp_name"],$imagepath3);
        } else {
            $imagepath3 = $_POST['image_3'];
        }

		// Image 4
        if (!empty($_FILES['image4']['name'])) {
            $img4 = $_FILES['image4']['name'];
            $temp4 = explode(".", $img4);
            $newfilename4 = round(microtime(true)) . '4.' . end($temp4);
            $imagepath4="ads_images/".$newfilename4;
            move_uploaded_file($_FILES["image4"]["tmp_name"],$imagepath4);
        } else {
            $imagepath4 = $_POST['image_4'];
        }

		// Get the data
        $id = $_POST['id'];
		$title = $_POST['title'];
		$category = $_POST['category'];
		$price = $_POST['price'];
		$company = $_POST['company'];
		$year = $_POST['year'];
		$model = $_POST['model'];
		$fuelType = $_POST['fuelType'];
		$kmDriven = $_POST['kmDriven'];
		$description = $_POST['description'];
		$location = $_POST['location'];
		$name = $_POST['name'];
		$phone = $_POST['phone'];
		$city = $_POST['city'];

		// Insert into Database
         $updateQuery = "UPDATE ads SET title = '$title', category = '$category', price = '$price', company = '$company', year = '$year', model = '$model', fuel_type = '$fuelType', km_driven = '$kmDriven', ad_description = '$description', location = '$location', image_1 = '$imagepath1', image_2 = '$imagepath2', image_3 = '$imagepath3', image_4 = '$imagepath4', name = '$name', mobile = '$phone', city = '$location' WHERE id = '$id' ";

		 if (mysqli_query($connection, $updateQuery)) {
			echo("<script>location.href = 'index.php?msg=Ad has been updated successfully';</script>");
		} else {
			 echo "Erro while submit ad : " . mysqli_error($connection);
		}

	}

?>