
<?php
	include "connection.php";
	extract($_POST);
	$encrypted_password=md5($pass);
	$sql="insert into user_info(name,password,phoneNo,city,email) values ('$username','$encrypted_password','$phoneNo','$city','$email')";
	$execute=$connection->query($sql);
	if($execute)
	{
		header("location: index.php?msg=You are signed up successfully!");

	}
	else
	{
		header("location: index.php?msg=Error while sign up. please ty again!");
	}
?>
	
	