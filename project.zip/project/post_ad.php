﻿<?php
  session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Post Ad</title>
  <link rel="stylesheet" type="text/css" href="css/deal.css" />
  <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/left_menu_panel.css" />
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/submit_ad.css" />
  <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />

  <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>


  <link rel="stylesheet" type="text/css" href="jquery.bxslider.css">
  <link rel="stylesheet" type="text/css" href="jquery.bxslider.min.css">

  

  <style>
    .shop_bt:hover {
      text-decoration: underline;
      background-color: rgb(27, 39, 51);
    }
    a:hover {
        text-decoration: underline;
       
      }
    
  </style>

</head>

<body>
  <div class="main_wrapper">
    <!--Header-->

  <div class="header"style="background-color:darkcyan;">
    <div class="log" style="margin-top:30px; margin-left:50px; width:50px;" ><a href="index.php" style="background:white;color:black;">Home</a></div>
    <div class="logo">
      <img src="images/logo.png" height="150px" style="margin-top: -20px;margin-left:-150px;" />
    </div>
    <div style="clear: both"></div>
  </div>
  <div style="clear:both;"></div>
</div>


    <!--ENd Header-->

    <div class="submit_ad">
      <div class="submit_top" style="background-color:darkcyan;">
        <h1>Submit your Ad</h1>
      </div>

      <div class="f_container">
        <div class="group_container">
          <form method="post" name="myForm" action="submit_ad.php" enctype="multipart/form-data">
            <div class="form_group">
              <label class="shop_label">Post Tittle</label>
              <input class="shop_textbox" name="title" placeholder="Post Tittle" type="text" />
            </div>

            <div class="form_group">
              <label class="shop_label">Category</label>
              <select class="shop_ddb" name="category">
                <option value="0">Select Category</option>
                <option value="rent">Rent</option>
                <option value="sale">Sale</option>
              </select>
            </div>

        </div>

        <hr />

        <div class="group_container">

          <div class="form_group">
            <label class="shop_label">Price</label>
            <input class="shop_textbox" name="price" placeholder="In rupees" type="text" />
          </div>

          <div class="form_group">
            <label class="shop_label">Company</label>
            <select class="shop_ddb" name="company">
              <option value="0">Select Company</option>
              <option value="Toyota">Toyota</option>
              <option value="Suzuki">Suzuki</option>
              <option value="Honda">Honda</option>
              <option value="Mercedes">Mercedes</option>
              <option value="Jaguar">Jaguar</option>
              <option value="Tesla">Tesla</option>
              <option value="Audi">Audi</option>
              <option value="KIA">KIA</option>
              <option value="BMW">BMW</option>
            </select>
          </div>

          <div class="form_group">
            <label class="shop_label">Year</label>
            <input class="shop_textbox" name="year" placeholder="Year" type="text" />
          </div>

          <div class="form_group">
            <label class="shop_label">Model</label>
            <input class="shop_textbox" name="model" placeholder="Model" type="text" />
          </div>

          <div class="form_group">
            <label class="shop_label">Fuel Type</label>
            <select class="shop_ddb" name="fuelType">
              <option value="0">Select Fuel Type</option>
              <option value="Petrol">Petrol</option>
              <option value="Diesel">Diesel</option>
            </select>
          </div>

          <div class="form_group">
            <label class="shop_label">KM. Driven</label>
            <input class="shop_textbox" name="kmDriven" placeholder="In KM" type="text" />
          </div>
        </div>

        <hr />

        <div class="group_container">
          <div class="form_group">
            <label class="shop_label">Ad Discription</label>
            <input class="shop_dis" name="description" placeholder="Company Name" type="text" />
          </div>
        </div>


        <hr />

        <div class="group_container">
          <div class="form_group">
            <label class="shop_label">Upload Pic</label>
         
            <div class="choose_file">
              <input name="image1" type="file" id="img1_file"  alt=""/>
              <img id="img1_prev" alt="" src="" width="77px" height="77px"  style="border-radius: 5px; " />
            </div>

            <div class="choose_file">
              <input name="image2" type="file" id="img2_file" />
              <img id="img2_prev" alt="" src="#" width="77px" height="77px" style="border-radius: 5px;" />
            </div>

            <div class="choose_file">
              <input name="image3" type="file" id="img3_file" />
              <img id="img3_prev" alt="" src="#" width="77px" height="77px" style="border-radius: 5px;" />
            </div>

            <div class="choose_file">
              <input name="image4" type="file" id="img4_file" />
              <img id="img4_prev" alt="" src="#" width="77px" height="77px" style="border-radius: 5px;" />
            </div>
            
          </div>
        </div>

        <hr />

        <div class="group_container">
          <div class="form_group">
            <label class="shop_label">Name</label>
            <input class="shop_textbox" name="name" placeholder="Your Name" type="text" value="<?= $_SESSION['name']; ?>" readonly />
          </div>

          <div class="form_group">
            <label class="shop_label">Mobile No</label>
            <input class="shop_textbox" name="phone" placeholder="Mobile No" type="text" value="<?= $_SESSION['phone']; ?>" readonly />
          </div>


          <div class="form_group">
            <label class="shop_label">City</label>
            <input class="shop_textbox" name="city" placeholder="City Name" type="text" value="<?= $_SESSION['city']; ?>" readonly />
          </div>

          <div class="form_group">
            <label class="shop_label">Location</label>
            <input class="shop_textbox" name="location" placeholder="Location" type="text" />
          </div>

          <div class="form_group">
            <input type="submit" class="shop_bt" value="SUBMIT AD" style="background-color:darkcyan;"/>
          </div>
          </form>

        </div>
      </div>
    </div>

    <!-- Start footer -->
    <div class="footer" style="height: 150px;background:darkcyan; border-top: 5px solid black;">
      <div class="f1">
        
        <p>
          <b>Widely</b> known as Pakistan's no. 1 online classifieds platform,
          where you can sale rent and purchase your cars without any worry
          Our aim is to empower every person in the country to
          independently connect with buyers and sellers online. We care about
          you — and the transactions that bring you closer to your dreams.
          Want to buy your first car? We’re here for you. Want to sell
          commercial property to buy your dream home? We’re here for you.
          Whatever job you’ve got, we promise to get it done.
        </p>

        
      </div>

      <div class="f3">
        <h2>SOCIAL</h2>
        <ul>
          <a href="https://www.facebook.com/aqsa.shafiq.1111">
            <li><img src="images/fb.png" /></li>
          </a>
          <a href="https://twitter.com/ManiJut07962763">
            <li><img src="images/twitter.png" /></li>
          </a>
         
          <a href="https://youtube.com/channel/UCjccFNGaezJHBEkL8XLTdug">
            <li><img src="images/you.png" /></li>
          </a>
        </ul>

        <div class="post_ad" style="  background:white; color: black;">POST AD</div>
      </div>

      <div class="f2">
        <h2 style="padding-left: 50px; color: #f1f1f1">
          <i class="fa fa-building" aria-hidden="true"></i> CITIES
        </h2>
        <ul class="f_2">
          <li>Karachi</li>
          <li>Faisalabad</li>
          <li>Multan</li>
          <li>Gujranwala</li>

        </ul>

        <ul class="f_2">
          <li>Lahore</li>
          <li>Rawalpindi</li>
          <li>Peshawar</li>
          <li>Quetta</li>

        </ul>

        <ul class="f_2">
          <li>Islamabad</li>
          <li>Bahawalpur</li>
          <li>Okara</li>
          <li>Jhelum</li>
 
          
        </ul>
      </div>

      <div style="clear: both"></div>
    </div>
    <!--End Footer-->
  </div>


      <script type="text/javascript">
        $(window).scroll(function () {
          if ($(this).scrollTop() > 135) {
            $('.searchbar').addClass('fixed');
          } else {
            $('.searchbar').removeClass('fixed');
          }
        });
      </script>



      <script src="jquery.bxslider.js" type="text/javascript"></script>
      <script src="jquery.bxslider.min.js" type="text/javascript" charset="utf-8"></script>
      <script type="text/javascript">
        $(document).ready(function () {
          $('.slider1').bxSlider({
            slideWidth: 150,
            slideHeight: 180,
            minSlides: 4,
            maxSlides: 8,
            slideMargin: 15
          });
        });
      </script> 

  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <script>
    img1_file.onchange = evt => {
      const [file] = img1_file.files
      if (file) {
        img1_prev.src = URL.createObjectURL(file)
      }
    }

    img2_file.onchange = evt => {
      const [file] = img2_file.files
      if (file) {
        img2_prev.src = URL.createObjectURL(file)
      }
    }

    img3_file.onchange = evt => {
      const [file] = img3_file.files
      if (file) {
        img3_prev.src = URL.createObjectURL(file)
      }
    }

    img4_file.onchange = evt => {
      const [file] = img4_file.files
      if (file) {
        img4_prev.src = URL.createObjectURL(file)
      }
    }
</script>

</body>

</html>