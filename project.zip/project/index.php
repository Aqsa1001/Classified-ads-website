﻿<?php 
  require 'connection.php';
  session_start();
 ?>
<!DOCTYPE html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Home</title>
  <link rel="stylesheet" type="text/css" href="css/deal.css" />
  <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet" />
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" />
  <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" />

  <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
  <script src="js/script.js"></script>

  <link rel="stylesheet" type="text/css" href="jquery.bxslider.css" />
  <link rel="stylesheet" type="text/css" href="jquery.bxslider.min.css" />
  <style>
    a:hover {
      text-decoration: underline;
     
    }
  </style>
</head>

<body>
  <div class="main_wrapper">
    <!--Header-->

    <div class="header" style="background-color:darkcyan;">
      <div class="logo">
        <img src="images/logo.png" height="150px" style="margin-top: -20px" />
      </div>
      <div class="h_right">

        <?php
        if (!isset($_SESSION['name'])) { ?>
          <div class="log"><a href="signIn.html">SIGN IN</a></div>
          <div class="join">JOIN FREE</div>
        <?php } ?>

        <?php if (isset($_SESSION['name'])) { ?>
          <div class="ad"><a href="post_ad.php" style=" background:white;color:black;">POST AD</a></div>
        <?php } ?>

        <div style="clear: both"></div>
      </div>
      <div style="clear: both"></div>
    </div>

    <!--ENd Header-->

    <!-- Searchbar-->

    <?php if (isset($_SESSION['name'])) { ?>
      <div style="background:white; height: 80px">
        
        <img src="images/profile.jpg " height="40px" width="40px" style="
            margin-left: -850px;
            margin-top: 10px;
            margin-bottom: -12px;
            border-radius: 50px;
          " />
        <span><b>Welcome: <?= $_SESSION['name']; ?></b></span>
        <div class="dropdown">
          <img src="images/setting.jpg " height="40px" width="40px" style="
              margin-left: 10px;
              margin-top: 20px;
              margin-bottom: -12px;
              border-radius: 50px;
            " />
          <div class="dropdown-content">
            <a href="account_settings.php">Account Setting</a>
            <a href="ads_settings.php">Ads Setting</a>
            <a href="logout.php">Log out</a>
          </div>
        </div>

        <form action="search.php" style="display: inline">
          <input class="txtbox" name="search" type="text" style="margin-left: 150px" />
          <button type="submit" class="search_bt" style="background:black ;">Search</button>
        </form>
        <div style="clear: both"></div>
      </div>
    <?php } ?>
    <!--End Searchbar-->

    <!--Content-->
    <div class="content">

      <div class="c_left">

      </div>
      <div class="c_right">

        <?php if (isset($_GET['msg'])) { ?>
          <div class="alert mb-5"style="background-color:darkcyan;">
            <h4><?= $_GET['msg']; ?></h4>
          </div>
        <?php } ?>

        <?php if (isset($_GET['err'])) { ?>
          <div class="alert alert-error mb-5">
            <h4><?= $_GET['err']; ?></h4>
          </div>
        <?php } ?>

        <div class="c_right_container">
          <ul class="my_category">
            <a href="show_brand.php?brand_name=Toyota&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/toyotaLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> Toyota </span>
                </div>
              </li>
            </a>

            <a href="show_brand.php?brand_name=Suzuki&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/suzukiLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> Suzuki </span>
                </div>
              </li>
            </a>

            <a href="show_brand.php?brand_name=Honda&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/hondaLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> Honda </span>
                </div>
              </li>
            </a>

            <a href="show_brand.php?brand_name=Mercedes&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/mercedesLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> Mercedes </span>
                </div>
              </li>
            </a>

            <a href="show_brand.php?brand_name=Jaguar&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/jaguarLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> Jaguar </span>
                </div>
              </li>
            </a>

            <a href="show_brand.php?brand_name=Tesla&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/teslaLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> Tesla </span>
                </div>
              </li>
            </a>

            <a href="show_brand.php?brand_name=Audi&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/audiLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> Audi </span>
                </div>
              </li>
            </a>

            <a href="show_brand.php?brand_name=Kia&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/kiaLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> Kia </span>
                </div>
              </li>
            </a>

            <a href="show_brand.php?brand_name=bmw&category=sale">
              <li>
                <div class="boxi">
                  <span><img src="images/bmwLogo.png" style="margin-top: 10px" alt="Elo" /></span>
                  <span> BMW </span>
                </div>
              </li>
            </a>
            <div style="clear: both"></div>
          </ul>

          <div style="clear: both"></div>
        </div>

        <div class="recent_post mt-5">
          <h1 class="cat_h mt-5">Latest Car Ads</h1>

          <div class="slider1">
          <?php
            $query = "SELECT * FROM `ads` order by id desc";
            $result = mysqli_query($connection, $query);
            while($ad = mysqli_fetch_assoc($result)) { ?> 
            <a href="AdDetails.php?id=<?= $ad['id']; ?>">
            <div class="slide">
              <div class="c--anim-btn">
                <span class="c-anim-btn">
                  <img src="<?= $ad['image_1']; ?>" />
                </span>
              
                <span> <?= $ad['title']; ?> </span>
              </div>
              </div>
            </a>
            <?php } ?>
          </div>
        </div>
      </div>
      <div style="clear: both;"></div>
    </div>

    <!--ENd Content-->
    <!-- Start footer -->
    <div class="footer" style="height: 150px;background:darkcyan; border-top: 5px solid black;">
      <div class="f1">
        
        <p>
          <b>Widely</b> known as Pakistan's no. 1 online classifieds platform,
          where you can sale rent and purchase your cars without any worry
          Our aim is to empower every person in the country to
          independently connect with buyers and sellers online. We care about
          you — and the transactions that bring you closer to your dreams.
          Want to buy your first car? We’re here for you. Want to sell
          commercial property to buy your dream home? We’re here for you.
          Whatever job you’ve got, we promise to get it done.
        </p>

        
      </div>

      <div class="f3">
        <h2>SOCIAL</h2>
        <ul>
          <a href="https://www.facebook.com/aqsa.shafiq.1111">
            <li><img src="images/fb.png" /></li>
          </a>
          <a href="https://twitter.com/ManiJut07962763">
            <li><img src="images/twitter.png" /></li>
          </a>
         
          <a href="https://youtube.com/channel/UCjccFNGaezJHBEkL8XLTdug">
            <li><img src="images/you.png" /></li>
          </a>
        </ul>

        <div class="post_ad" style="  background:white; color: black;">POST AD</div>
      </div>

      <div class="f2">
        <h2 style="padding-left: 50px; color: #f1f1f1">
          <i class="fa fa-building" aria-hidden="true"></i> CITIES
        </h2>
        <ul class="f_2">
          <li>Karachi</li>
          <li>Faisalabad</li>
          <li>Multan</li>
          <li>Gujranwala</li>

        </ul>

        <ul class="f_2">
          <li>Lahore</li>
          <li>Rawalpindi</li>
          <li>Peshawar</li>
          <li>Quetta</li>

        </ul>

        <ul class="f_2">
          <li>Islamabad</li>
          <li>Bahawalpur</li>
          <li>Okara</li>
          <li>Jhelum</li>
 
          
        </ul>
      </div>

      <div style="clear: both"></div>
    </div>
    <!--End Footer-->
  </div>


  <script type="text/javascript">
    $(window).scroll(function() {
      if ($(this).scrollTop() > 135) {
        $(".searchbar").addClass("fixed");
      } else {
        $(".searchbar").removeClass("fixed");
      }
    });
  </script>

  <script src="jquery.bxslider.js" type="text/javascript"></script>
  <script src="jquery.bxslider.min.js" type="text/javascript" charset="utf-8"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $(".slider1").bxSlider({
        slideWidth: 150,
        slideHeight: 180,
        minSlides: 4,
        maxSlides: 8,
        slideMargin: 15,
      });
    });
  </script>

  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>